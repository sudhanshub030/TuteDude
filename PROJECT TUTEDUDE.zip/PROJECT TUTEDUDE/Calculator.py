from tkinter import *

window = Tk()
window.geometry("300x600")

e  = Entry(window, width=16, font=("Arial", 24), borderwidth=2, relief="ridge")
e.place(x=0, y=0)

def click(num):
    result = e.get()
    e.delete(0,END)
    e.insert(0, str(result) + str(num))
    
b = Button(window, text="1", padx=40, pady=20, font=("Arial", 18), command=lambda:click(1))
b.place(x=0, y=70)

b = Button(window, text="2", padx=40, pady=20, font=("Arial", 18), command=lambda:click(2))
b.place(x=100, y=70)

b = Button(window, text="3", padx=35, pady=20, font=("Arial", 18), command=lambda:click(3))
b.place(x=200, y=70)

b = Button(window, text="4", padx=35, pady=20, font=("Arial", 18), command=lambda:click(4))
b.place(x=0, y=155)

b = Button(window, text="5", padx=35, pady=20, font=("Arial", 18), command=lambda:click(5))
b.place(x=100, y=155)

b = Button(window, text="6", padx=35, pady=20, font=("Arial", 18), command=lambda:click(6))
b.place(x=200, y=155)

b = Button(window, text="7", padx=35, pady=20, font=("Arial", 18), command=lambda:click(7))
b.place(x=0, y=240)

b = Button(window, text="8", padx=35, pady=20, font=("Arial", 18), command=lambda:click(8))
b.place(x=100, y=240)

b = Button(window, text="9", padx=35, pady=20, font=("Arial", 18), command=lambda:click(9))
b.place(x=200, y=240)

b = Button(window, text="0", padx=35, pady=20, font=("Arial", 18), command=lambda:click(0))
b.place(x=0, y=324)

def add():
    n1 = e.get()
    global math
    math = "addition"
    global i 
    i = int(n1)
    e.delete(0, END)
b = Button(window, text="+", padx=35, pady=20, font=("Arial", 18), command=add)
b.place(x=100, y=324)

def sub():
    n1 = e.get()
    global math
    math = "subtraction"
    global i 
    i = int(n1)
    e.delete(0, END)
b = Button(window, text="-", padx=38, pady=20, font=("Arial", 18), command=sub)
b.place(x=200, y=324)

def mul():
    n1 = e.get()
    global math
    math = "multiplication"
    global i 
    i = int(n1)
    e.delete(0, END)
b = Button(window, text="*", padx=40, pady=20, font=("Arial", 18), command=mul)
b.place(x=0, y=410)

def div():
    n1 = e.get()
    global math
    math = "division"
    global i 
    i = int(n1)
    e.delete(0, END)
b = Button(window, text="/", padx=40, pady=20, font=("Arial", 18), command=div)
b.place(x=100, y=410)

def equal():
    n2 = e.get()
    e.delete(0, END)
    if math == "addition":
        e.insert(0,i+int(n2))
    elif math == "subtraction" :
        e.insert(0,i-int(n2))
    elif math == "multiplication":
        e.insert(0,i*int(n2))
    elif math == "division":
        e.insert(0,i/int(n2))
b = Button(window, text="=", padx=35, pady=20, font=("Arial", 18), command=equal)
b.place(x=200, y=410)

def clear():
    e.delete(0,END)
b = Button(window, text="C", padx=35, pady=20, font=("Arial", 18), command=clear)
b.place(x=0, y=495)

mainloop()
